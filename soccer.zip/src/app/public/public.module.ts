import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollToModule,ScrollToService } from '@nicky-lenaers/ngx-scroll-to';
import { TeamComponent } from './team/team.component';
import { ChangeDetectorRef } from '@angular/core';
// For MDB Angular Free
import { MDBBootstrapModule ,ChartsModule, WavesModule } from 'angular-bootstrap-md';
import { FooterComponent } from './footer/footer.component'
import {RouterModule} from "@angular/router";
import { UpcomingComponent } from './upcoming/upcoming.component';
import { ErrorComponent } from './error/error.component';

@NgModule({
  declarations: [TeamComponent, FooterComponent, UpcomingComponent, ErrorComponent],
    exports: [
        FooterComponent,
        UpcomingComponent,
        ErrorComponent
    ],
  imports: [
    CommonModule,
    ScrollToModule.forRoot(),
    ChartsModule, WavesModule, MDBBootstrapModule.forRoot(), RouterModule
  ]
})
export class PublicModule { }
