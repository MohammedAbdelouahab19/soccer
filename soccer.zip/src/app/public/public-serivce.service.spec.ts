import { TestBed } from '@angular/core/testing';

import { PublicSerivceService } from './public-serivce.service';

describe('PublicSerivceService', () => {
  let service: PublicSerivceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PublicSerivceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
