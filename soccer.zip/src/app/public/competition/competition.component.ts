import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {PublicSerivceService} from '../public-serivce.service';
import {ActivatedRoute, Router} from '@angular/router';
import {ScrollToConfigOptions, ScrollToService } from '@nicky-lenaers/ngx-scroll-to';
import {FunctionsService} from "../functions.service";


@Component({
  selector: 'app-competition',
  templateUrl: './competition.component.html',
  styleUrls: ['./competition.component.scss']
})
export class CompetitionComponent implements OnInit {
  currentTime = null;
  title = '90MIN FOOTBALL';

  destination = 'destination';
  response = '';
  currentCompetition = null;
  competitionName: string = '90MIN SOCCER';
  flag: string = null;
  teams = [];
  currentDivScroll = 'rank';

  nextMatchs = [];
  lastResult = [];
  currentDtEpoch = null;

  day = null;
  month = null;

  currentDay = null;
  currentMonth = null;

  nextMatchCheck = true;
  currentMatchCheck = true;
  teamsExist = false;
  dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  competitionCountry = [];

  loadingRank = true;
  error = false;

  constructor(private urlRoute:Router,private functions: FunctionsService,private cdRef:ChangeDetectorRef,private scrollToService: ScrollToService,private publicService: PublicSerivceService, private route: ActivatedRoute) { }

  triggerScrollTo(div) {
    const config: ScrollToConfigOptions = {
      target: div
    };
    this.scrollToService.scrollTo(config);
    this.currentDivScroll = div;
  }

  ngOnInit(): void {
    this.title = this.urlRoute.url.replace('/competition/','');
    this.title = this.title.replace('-live-scores','');
    this.currentCompetition = this.route.params.subscribe(params => {
      this.currentCompetition = params['id'];
      this.getRankTeamOfCompetition();
      this.currentDay = (new Date()).getDate();
      this.currentMonth = (new Date()).getMonth()+1;
    });

  }

  getRankTeamOfCompetition() {
    this.currentCompetition = this.currentCompetition.replace('-live-scores','');
      this.publicService.getCompetition(this.currentCompetition).subscribe((data: any) => {
        if(this.functions.handleErrorData(data.response)){
          this.error = true;
        }else{
          this.currentDtEpoch = data.currentTime;

          this.competitionName = data.response?.standings?.compName;
          this.title = this.competitionName;

          this.nextMatchs = data.response?.fixtures;
          this.lastResult = data.response?.results;
          this.flag = data.response.standings?.flag;
          if(data.response.standings){
            this.teams = data.response.standings?.rows;
            this.teamsExist = true;
          }
          this.currentTime = new Date(data.currentTime*1000);

          var limitLastResult = this.lastResult.length;
          if(limitLastResult>8){
            limitLastResult = 8;
          }
          for(let i=0;i<this.nextMatchs.length;i++) {
            this.nextMatchs[i].team1 = this.nextMatchs[i].s1.replace(' ','-');
            this.nextMatchs[i].team2 = this.nextMatchs[i].s2.replace(' ','-');
          }

          for(let i=0;i<limitLastResult;i++) {
              this.lastResult[i].team1 = this.lastResult[i].s1.replace(' ','-');
              this.lastResult[i].team2 = this.lastResult[i].s2.replace(' ','-');

              this.lastResult[i].currentMin1H = Math.floor((this.currentDtEpoch - this.lastResult[i]?.dt) / 60);
              this.lastResult[i].currentMin2H = Math.floor((this.currentDtEpoch - this.lastResult[i]?.wh) / 60);
              if(this.nextMatchs[i]){
                this.nextMatchs[i].currentMin1H =  Math.floor((this.currentDtEpoch - this.nextMatchs[i]?.dt) / 60);
              }
              if(this.nextMatchs[i]){this.nextMatchs[i].currentMin2H =  Math.floor((this.currentDtEpoch - this.lastResult[i]?.wh) / 60);}
          }

          for(let i=0;i<this.nextMatchs.length;i++){
            let minute = null , hour = null;
            let date =  new Date(this.nextMatchs[i].dt*1000)
            this.nextMatchs[i].fullDate = date;
            minute = date.getMinutes();
            hour = date.getHours();
            if(minute < 10){
              minute = '0' + minute;
            }
            if(hour < 10){
              hour = '0' + hour;
            }
            this.nextMatchs[i].time = hour + ':' + minute;
            this.nextMatchs[i].minute = minute;
            this.nextMatchs[i].dayName = this.dayNames[date.getDay()];
            this.nextMatchs[i].hour = hour;
            this.nextMatchs[i].day = date.getDate();
            this.nextMatchs[i].month = date.getMonth()+1;
            this.nextMatchs[i].year = date.getFullYear();
            if(this.nextMatchs[i].s != '-'){
              this.nextMatchs[i].currentMinute = this.nextMatchs[i].dt-this.nextMatchs[i].wh;
            }
          }
        }
        this.loadingRank = false;
      });

  }


  changeDayMonth(day, month){
    this.day = day;
    this.month = month;
  }

  currentMatchExist(){
    this.currentMatchCheck = false;
  }

  nextMatchExist(){
    this.nextMatchCheck = false;
  }

  log(value){
    console.log(value)
  }

  nameToLinkTeam(value){
    var res = (value.replace(' ','-')).trim();
    return res;
  }

  deleteTwoPointSpace(value){
    if(value != undefined) {
      var res = value.replace(':', '');
      res = res.replace(/\s/g, '-');
      res = res.replace(' ', '-');
      res = res.replace('  ', '-');
      res = res.replace('   ', '-');
      res = res.replace('    ', '-');
      res = res.replace('-------', '-');
      res = res.replace('------', '-');
      res = res.replace('-----', '-');
      res = res.replace('----', '-');
      res = res.replace('---', '-');
      res = res.replace('--', '-');
      res = res.replace('-', '-');
    }else{
      res = 'team name';
    }
    return res
  }
}
