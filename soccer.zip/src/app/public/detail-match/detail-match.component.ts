import { Component, OnInit } from '@angular/core';
import {PublicSerivceService} from "../public-serivce.service";
import {ScrollToService} from "@nicky-lenaers/ngx-scroll-to";
import {ActivatedRoute, Router} from "@angular/router";
import {FunctionsService} from "../functions.service";

@Component({
  selector: 'app-detail-match',
  templateUrl: './detail-match.component.html',
  styleUrls: ['./detail-match.component.scss']
})
export class DetailMatchComponent implements OnInit {

  title = '90MIN FOOTBALL';
  error = false;
  team1 = null;
  team2 = null;

  state1 = ['possession','shot','shotOnGoal'];

  public chartType: string = 'pie';

  public chartDatasets: Array<any> ;


  chartLabels: any;
  public chartColors: Array<any> = [
    {
      backgroundColor: ['#F7464A', '#46BFBD'],
      hoverBackgroundColor: ['#FF5A5E', '#5AD3D1'],
      borderWidth: 2,
    }
  ];

  public chartOptions: any = {
    responsive: true
  };
  public chartClicked(e: any): void { }
  public chartHovered(e: any): void { }

  constructor(private urlRoute:Router,private functions: FunctionsService,private publicService: PublicSerivceService, private route: ActivatedRoute) { }

  teams = null;

  currentDateEpoche = null;

  tempArray = [];

  response = null;
  event = [];

  competitionName = null;
  date = null;
  day = null;
  month = null;
  year = null;
  hour = null;
  minute = null;
  score1 = null;
  score2 = null;
  idTeam1 = null;
  idTeam2 = null;
  teamA = null;
  teamB = null;
  competitionNameC = null;
  country = null;
  idCompetition = null;
  cmpt = null;
  state = null;
  currentMinute = null
  daysLeft = null;
  hoursLeft = null;
  minuteLeft = null;

  detailMatchCheck = false;
  detailMatch:any;
  possessionExiste = false;
  players = [];
  players2 = [];
  infoTeam:any;
  f1 = [];
  f2 = [];
  subPlayerDisplay = false;
  currentDtEpoch = null;
  formationShowed = 1;

  Dplayers:any=[];
  Mplayers:any=[];
  Fplayers:any=[];

  Dplayers2:any=[];
  Mplayers2:any=[];
  Fplayers2:any=[];
  currentMin1H = null;
  currentMin2H = null;

  // for apply style or not
  mt1 = false;
  mt2 = false;
  idMatch = null;

  load = false;

  ngOnInit(): void {
    try {
      let array = this.urlRoute.url.split('/');
      let teams = array[3].split('-vs-');
      this.title = teams[0] + ' - ' + teams[1];
    }catch (title){
    }
    //this.getDate();
    this.load = true;
    this.getTeam1andTeam2();
    this.getDetailMatch(this.idMatch);
    //this.getDetailMatch2();
  }

  getDate(){
    this.currentDateEpoche = (Date.now()).toString();
    this.currentDateEpoche = this.currentDateEpoche.substring(0,10);
  }

  getDetailMatch(idMatch){
    this.publicService.getDetailMatch(idMatch).subscribe((data: any) => {
      this.response = data.response;
      if(this.functions.handleErrorData(this.response)){
        this.error = true;
      }else{
        this.event = this.response.ev;

        this.response.competitionName = this.response.cn;
        if(this.response.cc && this.response.cn){
          this.response.competitionName = this.response.cn.substring(this.response.cc.length+2);
        }

        this.response.competitionName = this.response.cn;
        this.date = new Date(0); // The 0 there is the key, which sets the date to the epoch
        this.date.setUTCSeconds(this.response.dt);
        this.response.date = this.date;

        this.response.day = (this.response.date).getDate();
        this.response.month = (this.response.date).getMonth()+1;
        this.response.year = (this.response.date).getFullYear();
        this.response.minute = (this.response.date).getMinutes();
        this.response.hour = (this.response.date).getHours();

        this.competitionName = this.response.competitionName;
        this.date = this.response.date;
        this.day = this.response.day;
        this.month = this.response.month;
        this.year = this.response.year;
        this.hour = this.response.hour;
        this.minute = this.response.minute;
        this.score1 = this.response.sc1;
        this.score2 = this.response.sc2;
        this.idTeam1 = this.response.s1Id;
        this.idTeam2 = this.response.s2Id;
        this.teamA = this.response.s1;
        this.teamB = this.response.s2;
        this.cmpt = this.response?.fl;
        this.cmpt = this.response?.ccId + '.png';

        //this.competitionNameC = this.response.cn.substring(this.response.cc.length+2);
        this.competitionNameC = this.response.cn;
        if(this.response.cn && this.response.cc){
          this.response.competitionName = this.response.cn.substring(this.response.cc.length+2);
        }

        this.competitionNameC = this.response.cn;
        this.country = this.response.cc;
        this.idCompetition = this.response.ccId;
        this.state = this.response.s;

        const date = new Date();
        const month = date.getMonth()+1;
        const day = date.getDate();
        const year = date.getFullYear();
        const hour = date.getHours();
        const minute = date.getMinutes();

        var date1: any;
        var date2: any;
        date1 = new Date(this.month + '/' + this.day + '/' + this.year + ' ' + this.hour + ':' + this.minute);
        date2 = new Date(month + '/' + day + '/' + year + ' ' + hour + ':' + minute);
        const diffTime = Math.abs(date2 - date1);

        const diffHours = Math.abs(date2 - date1)/36e5;
        const diffDays = diffTime / (1000 * 60 * 60 * 24);
        const minuteLeft = diffTime / (1000 * 60 * 60 * 24 * 60);

        this.daysLeft = Math.floor(diffDays);
        this.hoursLeft = Math.floor(diffHours - (this.daysLeft * 24));
        this.minuteLeft = Math.floor((diffHours - (this.daysLeft * 24) - this.hoursLeft) * 60);

        if(this.response.st.length>0) {
          this.detailMatch = this.response.st;
          this.detailMatchCheck = true;
        }else{
          this.detailMatchCheck = false;
        }

        this.players = this.response.l1;
        this.players2 = this.response.l2;

        this.f1 = (this.response.f1).split('-');
        this.f2 = (this.response.f2).split('-');

        if(this.f1.length>3){this.mt1 = true;}
        if(this.f2.length>3){this.mt2 = true;}
        var a = 0;
        var b = 0;
        var c = 0;

        for(var i = 1;i<this.players.length;i++){
          if( i <= this.f1[0]*1){
            this.Dplayers[a] = this.players[i];
            a++;
          }
          if( this.f1[0]*1 < i && i <= this.f1[1]*1+ this.f1[0]*1 ){
            this.Mplayers[b] = this.players[i];
            b++;
          }
          if( this.f1[1]*1+ this.f1[0]*1 < i && i <= this.f1[1]*1+ this.f1[0]*1 + this.f1[2]*1 ){
            this.Fplayers[c] = this.players[i];
            c++;
          }
        }

        this.currentDtEpoch = data.currentTime;

        this.currentMin1H = Math.floor((this.currentDtEpoch - this.response?.dt) / 60);
        this.currentMin2H = Math.floor((this.currentDtEpoch - this.response?.wh) / 60);

        a = 0;
        b = 0;
        c = 0;

        for(var i = 1;i<this.players2.length;i++){
          if( i <= this.f2[0]*1){
            this.Dplayers2[a] = this.players2[i];
            a++;
          }
          if( this.f2[0]*1 < i && i <= this.f2[1]*1+ this.f2[0]*1 ){
            this.Mplayers2[b] = this.players2[i];
            b++;
          }
          if( this.f2[1]*1+ this.f2[0]*1 < i && i <= this.f2[1]*1+ this.f2[0]*1 + this.f2[2]*1 ){
            this.Fplayers2[c] = this.players2[i];
            c++;
          }
        }
      }
      this.load = false;
    });
  }

  getDetailMatch2(){
    this.publicService.getDetailMatch2(this.team1,this.team2).subscribe((data: any) => {
    });
  }

  getTeam1andTeam2(){
    this.teams = this.route.params.subscribe(params => {
      this.idMatch = params['idmatch'];
    });
  }

  fix(value){
    if(value=='save'){value = 'saves';}
    if(value=='corner'){value = 'Corners';}
    if(value=='foul'){value = 'Fouls';}
    if(value=='freeKick'){value = 'Free Kicks';}
    if(value=='throwin'){value = 'Throw-Ins';}
    return value;
  }

  calcul(v1, v2, limit){

      if (v1 > v2) {
        var w1 = '100%';
        var w2 = (v2 / v1) * 100 + '%';
      }
      if (v1 < v2) {
        var w2 = '100%';
        var w1 = (v1 / v2) * 100 + '%';
      }
      if (v1 == v2) {
        var w1 = '100%';
        var w2 = '100%';
      }

      return [w1,w2];
  }

  log(value){
    console.log(value)
  }

  getName(value){
    if(value) {
      let name = value.split(' ');

      if(name[1] != undefined){
        return name[1];
      }else {
        return name[0];
      }
    }
    return 1;
  }

  getFirstName(value){
    if(value) {
      let name = value.split(' ');

      if(name[1] != undefined){
        return name[0];
      }else {
        return null;
      }
    }
    return 1;
  }

  toogleDisplayFormation(value){
    this.formationShowed = value;
  }

  toogleDisplaySubPlayer(){
    var cmp = 0;
    if(this.subPlayerDisplay){
      this.subPlayerDisplay = false;
      cmp = 1;
    }
    if(!this.subPlayerDisplay && cmp == 0){
      this.subPlayerDisplay = true;
    }
  }

}
