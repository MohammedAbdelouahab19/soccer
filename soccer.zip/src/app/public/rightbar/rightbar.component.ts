import {Component, HostListener, OnInit} from '@angular/core';
import {PublicSerivceService} from "../public-serivce.service";

@Component({
  selector: 'app-rightbar',
  templateUrl: './rightbar.component.html',
  styleUrls: ['./rightbar.component.scss']
})
export class RightbarComponent implements OnInit {

  allCompetitionText = 'Show all Competitions';

  competitionCountry = [];
  competitions = [];
  upcoming:any;

  currentCountryLoop = null;
  pass = true;
  blog = false;

  newsModalState = false;
  competitionModalState = false;
  widthScreen = null;
  sizeM = false;

  constructor(private service: PublicSerivceService) { }

  ngOnInit(): void {
    this.widthScreen = window.innerWidth;
    this.sizeM = this.widthScreen < 701 ? true : false;
    this.getAllCompetition();
  }

  showAllCompetition(){
    if(this.allCompetitionText == 'Show all Competitions'){
      this.allCompetitionText = 'Hide all Competitions';
    } else{
      this.allCompetitionText = 'Show all Competitions';
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.widthScreen = event.target.innerWidth;
    this.sizeM = this.widthScreen < 701 ? true : false;
  }

  distinctCountry(lastId, newId){
    if(lastId != newId){
      this.currentCountryLoop = newId;
    }
  }

  getAllCompetition(){
    this.service.getAllCompetition().subscribe((data: any)=>{
      this.competitions = data.response.competitions;
      this.upcoming = data.response.trending.matches;
    })
  }

  displayCountryCompetition(countryId){
    var ar = Array.from(document.getElementsByClassName(countryId) as HTMLCollectionOf<HTMLElement>)
    var value = getComputedStyle(ar[0]).getPropertyValue('display');

    if (value == 'block') {
      for (var i = 0; i < ar.length; i++) {
        ar[i].style.display = 'none';
      }
    }

    if (value == 'none') {
      for (var i = 0; i < ar.length; i++) {
        ar[i].style.display = 'block';
      }
    }
  }

  openModal(value){
    if(value == 'close'){
      this.newsModalState = false;
      this.competitionModalState = false;
    }
    if(value == 'news'){
      if(this.newsModalState){
        this.newsModalState = false;
        this.competitionModalState = false;
      }else{
        this.newsModalState = true;
        this.competitionModalState = false;
      }
    }
    if(value == 'competition'){
      if(this.competitionModalState){
        this.competitionModalState = false;
        this.newsModalState = false;
      }else{
        this.competitionModalState = true;
        this.newsModalState = false;
      }
    }
    console.log('competition : ',this.competitionModalState);
    console.log('news : ',this.newsModalState);
  }

}
