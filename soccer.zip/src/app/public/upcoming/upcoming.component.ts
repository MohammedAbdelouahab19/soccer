import { Component, OnInit } from '@angular/core';
import {PublicSerivceService} from "../public-serivce.service";
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-upcoming',
  templateUrl: './upcoming.component.html',
  styleUrls: ['./upcoming.component.scss']
})
export class UpcomingComponent implements OnInit {

  constructor(private publicService: PublicSerivceService, private route: ActivatedRoute) { }
  upcoming:any;

  ngOnInit(): void {
    this.getAssets();
  }
  getAssets(){
    this.publicService.getAllCompetition().subscribe(data=>{
      let dataa:any = data;
      this.upcoming = dataa.response.trending.matches;
    })
  }

  teamToLinkName(value){
    return value.replace(' ','-');
  }

  deleteTwoPointSpace(value){
    var res = value.replace(':','');
    res = res.replace(/\s/g,'-');
    res = res.replace(' ','-');
    res = res.replace('  ','-');
    res = res.replace('   ','-');
    res = res.replace('    ','-');
    res = res.replace('-------','-');
    res = res.replace('------','-');
    res = res.replace('-----','-');
    res = res.replace('----','-');
    res = res.replace('---','-');
    res = res.replace('--','-');
    res = res.replace('-','-');
    return res
  }

}
