import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient,HttpClientModule } from '@angular/common/http';
import Swal from "sweetalert2";
import {throwError} from "rxjs";
import {catchError} from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class PublicSerivceService {

  optionRequete = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin':'*',
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
      "Access-Control-Allow-Headers": "X-Requested-With, content-type, Authorization"
    })
  };

  dateNow = null;

  urlCompetition = 'https://www.scorebat.com/api/competition/3/';

  urlDetailMatch = 'https://www.scorebat.com/api/feed/game/';

  urlDetailMatch2 = 'https://www.scorebat.com/api/feed/match/';

  urlAllComeptition = 'https://www.scorebat.com/api/assets';

  urlAllMatches = 'https://www.scorebat.com/api/feed/';

  urlAllMatchesChangeDay = 'https://www.scorebat.com/api/feed/date/';

  response:any;

  constructor(private http: HttpClient) { }

  //const headers = {       'Accept': 'application/json, text/plain, */*',       'Access-Encoding': 'gzip, deflate',       'Access-Control-Allow-Origin': '*',       'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',       'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token'}


  generateDateNowEpoch(){
    this.dateNow = new Date().getTime();
  }

  getAllCompetition(){
    this.generateDateNowEpoch();
    return this.http.get(this.urlAllComeptition + '/?_='+ this.dateNow +'&sf=1')
      .pipe(
      catchError(this.handleError)
    );
  }

  getAllMatches(){
    this.generateDateNowEpoch();
    return this.http.get(this.urlAllMatches + '/?_='+ this.dateNow +'&sf=1')
      .pipe(
        catchError(this.handleError)
      );
  }

  getAllMatchesByDay(value){
    this.generateDateNowEpoch();
    return this.http.get(this.urlAllMatchesChangeDay + value + '/?_='+ this.dateNow +'&sf=1')
      .pipe(
        catchError(this.handleError)
      );
  }

  getCompetition(nomCompetition) {
    this.generateDateNowEpoch();
    return this.http.get(this.urlCompetition + nomCompetition + '/?_='+ this.dateNow +'&sf=1')
      .pipe(
        catchError(this.handleError)
      );
  }

  getDetailMatch(idMatch){
    this.generateDateNowEpoch();
    return this.http.get(this.urlDetailMatch + idMatch + '/?_='+ this.dateNow +'&sf=1')
      .pipe(
        catchError(this.handleError)
      );
  }

  getDetailMatch2(team1, team2){
    this.generateDateNowEpoch();
    return this.http.get(this.urlDetailMatch2 + team1 + '/' + team2 + '/?_='+ this.dateNow +'&sf=1')
      .pipe(
        catchError(this.handleError)
      );
  }

  handleError(error) {

    let errorMessage = '';

    if (error.error instanceof ErrorEvent) {

      // client-side error

      errorMessage = `Error: ${error.error.message}`;

    } else {

      // server-side error

      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;

    }
    Swal.fire({
      title: 'Failed!!',
      text: errorMessage,
      icon: 'error'
    });


    return throwError(errorMessage);

  }
}
