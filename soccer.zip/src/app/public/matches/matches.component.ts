import {Component, HostListener, OnInit} from '@angular/core';
import {PublicSerivceService} from '../public-serivce.service';
import {ActivatedRoute, ActivatedRouteSnapshot, Router} from '@angular/router';
import {matches} from "metismenujs/dist/types/util";
import {RightbarComponent} from "../rightbar/rightbar.component";

@Component({
  selector: 'app-matches',
  templateUrl: './matches.component.html',
  styleUrls: ['./matches.component.scss']
})
export class MatchesComponent implements OnInit {

  fullCalendar = false;
  scrollDivision = 'home';
  currentDate = 3;
  currentDtEpoch = null;
  matches:any;
  response:any;
  onlyCurrentMatch = false;
  competition:any;
  week = [];
  currentC = -1;
  displayNone = [];
  lastParent = 0;
  slice = 30;
  showMore = false;
  upcoming:any;

  days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  load = true;
  loadByDay = false;


  constructor(private publicService: PublicSerivceService, private route: ActivatedRoute) { }

  scrolled = false;

  @HostListener('window:scroll', ['$event'])
  onWindowScroll($event) {
    const numb = window.scrollY;
    if(numb > 165){
      this.scrolled = true;
    }else{
      this.scrolled = false;
    }
  }

  ngOnInit(): void {
    this.getAllMatches();
  }

  getAllMatches(){
    if(this.week.length!=0){
      this.loadByDay = true;
    }else{
      this.load = true;
    }
    this.publicService.getAllMatches().subscribe(res=>{
      this.response = res;
      this.currentDtEpoch = this.response.currentTime;
      this.matches = this.response.response.g;
      this.competition = this.response.response.c;
      if(this.week.length!=0){
        this.loadByDay = false;
      }else{
        this.get7Days();
        this.load = false;
      }
    })
  }

  getAssets(){
    this.publicService.getAllCompetition().subscribe(data=>{
      let dataa:any = data;
      this.upcoming = dataa.response.trending.matches;
    })
  }

  getAllMatchesByDay(value){
    this.response = [];
    this.competition = [];
    this.matches = [];
    this.loadByDay = true;
    this.publicService.getAllMatchesByDay(value).subscribe(res=>{
      this.response = res;
      this.currentDtEpoch = this.response.currentTime;
      this.matches = this.response.response.g;
      this.competition = this.response.response.c;
      this.loadByDay = false;
    })
  }

  log(value){
    console.log(value)
  }

  calendar(){
    var i = true;
    if(this.fullCalendar){
      this.fullCalendar = false;
      i = false;
    }
    if(!this.fullCalendar && i){
      this.fullCalendar = true;
    }
  }

  changeDivision(value){
    console.log(this.displayNone);
    this.scrollDivision = value;
    if(value == 'home'){
      this.onlyCurrentMatch = false;
      this.showMore = false;
    }
    if(value == 'rightnow'){
      this.onlyCurrentMatch = true;
    }
    if(value == 'allmatches'){
      this.onlyCurrentMatch = false;
      this.showMore = true;
    }
  }

  changeDate(value,date){
    if(this.currentDate != value){
      this.currentDate = value;
      if(value == 3){
        this.response = [];
        this.competition = [];
        this.matches = [];

        this.getAllMatches();
      }else {
        this.getAllMatchesByDay(date);
      }
    }
  }

  teamToLinkName(value){
    return value.replace(' ','-');
  }

  calculDateStart(dt){
    let minute = null , hour = null;
    let date =  new Date(dt*1000)
    minute = date.getMinutes();
    hour = date.getHours();
    if(minute < 10){
      minute = '0' + minute;
    }
    if(hour < 10){
      hour = '0' + hour;
    }
    return hour + ':' + minute;
  }

  calculCurrentMin(value){
    var res = Math.floor((this.currentDtEpoch - value) / 60);
    return res;
  }

  affectationC(value,i,pos){
    this.currentC = value;
    if(pos == 'top') {
      this.lastParent = i;
      this.displayNone.push(
        {
          'parent': this.lastParent,
          'displayNone': true
        }
      );
    }
    if(pos == 'bottom') {
      this.displayNone.push(
        {
          'parent': this.lastParent,
          'child' : i,
          'displayNone': true
        }
      );
    }
  }

  deleteTwoPointSpace(value){
    var res = value.replace(':','');
    res = res.replace(/\s/g,'-');
    res = res.replace(' ','-');
    res = res.replace('  ','-');
    res = res.replace('   ','-');
    res = res.replace('    ','-');
    res = res.replace('-------','-');
    res = res.replace('------','-');
    res = res.replace('-----','-');
    res = res.replace('----','-');
    res = res.replace('---','-');
    res = res.replace('--','-');
    res = res.replace('-','-');
    return res
  }

  myFunctionTernaire(value1,value2){
    var flag;
    if(value1 == undefined){
      flag = value2;
    }else{
      flag = value1;
    }
    return flag;
  }

  get7Days(){
    var newDate,date;
    for(var i = 3;i >=-3;i--){

      date = new Date(this.currentDtEpoch*1000);
      newDate = new Date(this.currentDtEpoch*1000-(86400000*(i)))
      this.week.push(
        {
          day : newDate.getDate(),
          name: this.days[newDate.getDay()],
          month: newDate.getMonth()+1,
          year: newDate.getFullYear()
        }
      );
    }
  }

  checkIfCurrentMatchExist(i,pos){
    this.displayNone[i].displayNone = false;
    if(pos=='sub'){
      this.displayNone[this.lastParent].displayNone = false;
    }
  }

  showMoreMatch(){
    var i = true;
    if(this.showMore){
      this.showMore = false;
      i = false;
    }
    if(!this.showMore && i==true){
      this.showMore = true;
      this.slice = 120;
    }
  }
}
