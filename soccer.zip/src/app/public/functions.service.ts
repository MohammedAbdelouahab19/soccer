import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FunctionsService {

  constructor() { }

  public handleErrorData(obj){
    let state:any = false;
    if(obj && Object.keys(obj).length === 0 && obj.constructor === Object || obj == null){
      state = true;
    }
    return state;
  }
}
