import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from '@angular/router';
import {DashboardComponent} from '../pages/dashboard/dashboard.component';
import {MatchesComponent} from './matches/matches.component';
import {DetailMatchComponent} from './detail-match/detail-match.component';
import {CompetitionComponent} from './competition/competition.component';
import {TeamComponent} from './team/team.component';
import {Page404Component} from "../extrapages/page404/page404.component";


const routes: Routes = [
  { path: '', component: MatchesComponent },
  { path: 'live-stream/:idmatch/:teams', component: DetailMatchComponent },
  { path: 'live-stream/:team', component: TeamComponent },
  { path: 'competition/:id', component: CompetitionComponent },
  { path: '**', component: Page404Component }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class PublicAppRoutingModule { }
