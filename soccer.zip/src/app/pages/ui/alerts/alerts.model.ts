// Alert Model Data
export interface AlertColor {
    color: string;
}
