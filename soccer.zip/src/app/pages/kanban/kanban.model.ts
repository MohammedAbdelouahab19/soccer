export interface Task {
    id: string;
    title: string;
    text: string;
    date: string;
    user: string[];
    status: string;
}
