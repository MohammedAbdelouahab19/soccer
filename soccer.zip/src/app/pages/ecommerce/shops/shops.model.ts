export interface Shops {
    image: string;
    title: string;
    name: string;
    products: number;
    balance: string;
}
