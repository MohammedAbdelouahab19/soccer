import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.90minsoccer.app',
  appName: '90minsoccer',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
